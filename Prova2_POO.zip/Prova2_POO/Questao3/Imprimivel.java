package Prova2_POO.Questao3;

interface Imprimivel {
   String imprimir() throws AnoPublicacaoInvalidoException; 

    
}
