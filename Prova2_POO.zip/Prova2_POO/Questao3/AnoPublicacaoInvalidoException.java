package Prova2_POO.Questao3;

public class AnoPublicacaoInvalidoException extends Exception {
    public AnoPublicacaoInvalidoException(String mensagem){
        super(mensagem);
    }

    
}
