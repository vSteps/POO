package Prova2_POO.Questao2;

interface Imprimivel {
   String imprimir(); 

    
}
