package Prova2_POO.Questao2;

public class Main {
    public static void main(String[] args) {
        Livro livro = new Livro("Harry Potter e a Câmara Secreta", "J.K. Rowling", 1998);
        System.out.println(livro.imprimir());
    }
    
}
