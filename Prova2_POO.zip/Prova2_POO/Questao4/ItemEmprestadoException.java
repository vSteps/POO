package Prova2_POO.Questao4;

public class ItemEmprestadoException extends Exception {
    public ItemEmprestadoException(String mensagem){
        super(mensagem);
    }
    
}
